name: "Goudy Bookletter 1911"
designer: "Barry Schwartz"
license: "OFL"
category: "SERIF"
date_added: "2011-02-09"
fonts {
  name: "Goudy Bookletter 1911"
  style: "normal"
  weight: 400
  filename: "GoudyBookletter1911.ttf"
  post_script_name: "GoudyBookletter1911"
  full_name: "Goudy Bookletter 1911"
  copyright: "Copyright (c) 2010, Barry Schwartz (crudfactory.com chemoelectric@chemoelectric.org)"
}
subsets: "menu"
subsets: "latin"
source {
  repository_url: "https://github.com/theleagueof/goudy-bookletter-1911"
  commit: "85ff5b834b4f63feb36fd2053949c19660580e48"
}
stroke: "SERIF"
classifications: "DISPLAY"
