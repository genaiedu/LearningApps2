name: "Cardo"
designer: "David Perry"
license: "OFL"
category: "SERIF"
date_added: "2011-09-07"
fonts {
  name: "Cardo"
  style: "normal"
  weight: 400
  filename: "Cardo-Regular.ttf"
  post_script_name: "Cardo-Regular"
  full_name: "Cardo"
  copyright: "Copyright (c) 2002-2011, David J. Perry (hospes02@scholarsfonts.net)"
}
fonts {
  name: "Cardo"
  style: "italic"
  weight: 400
  filename: "Cardo-Italic.ttf"
  post_script_name: "Cardo-Italic"
  full_name: "Cardo Italic"
  copyright: "Copyright (c) 2002-2011, David J. Perry (hospes02@scholarsfonts.net)"
}
fonts {
  name: "Cardo"
  style: "normal"
  weight: 700
  filename: "Cardo-Bold.ttf"
  post_script_name: "Cardo-Bold"
  full_name: "Cardo Bold"
  copyright: "Copyright (c) 2002-2011, David J. Perry (hospes02@scholarsfonts.net)"
}
subsets: "gothic"
subsets: "greek"
subsets: "greek-ext"
subsets: "hebrew"
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "old-italic"
subsets: "runic"
source {
  repository_url: "https://github.com/googlefonts/CardoFont"
  commit: "b2bf876b4e251ac44b343605464dad86b336b38d"
}
