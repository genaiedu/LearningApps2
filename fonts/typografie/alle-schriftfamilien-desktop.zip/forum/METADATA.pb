name: "Forum"
designer: "Denis Masharov"
license: "OFL"
category: "DISPLAY"
date_added: "2011-07-06"
fonts {
  name: "Forum"
  style: "normal"
  weight: 400
  filename: "Forum-Regular.ttf"
  post_script_name: "Forum"
  full_name: "Forum"
  copyright: "Copyright (c) 2011, Denis Masharov <denis.masharov@gmail.com>. This Font Software is licensed under the SIL Open Font License, Version 1.1. This license is available with a FAQ at: http://scripts.sil.org/OFL"
}
subsets: "menu"
subsets: "cyrillic"
subsets: "cyrillic-ext"
subsets: "latin"
subsets: "latin-ext"
stroke: "SERIF"
classifications: "DISPLAY"
source {
  repository_url: "https://github.com/librefonts/forum"
  commit: "e8efc0bceef3b98cf32f722bf637f3c110f68a37"
}
