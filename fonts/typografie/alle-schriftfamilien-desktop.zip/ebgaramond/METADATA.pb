name: "EB Garamond"
designer: "Georg Duffner, Octavio Pardo"
license: "OFL"
category: "SERIF"
date_added: "2011-03-23"
fonts {
  name: "EB Garamond"
  style: "normal"
  weight: 400
  filename: "EBGaramond[wght].ttf"
  post_script_name: "EBGaramond-Regular"
  full_name: "EB Garamond Regular"
  copyright: "Copyright 2017 The EB Garamond Project Authors (https://github.com/octaviopardo/EBGaramond12)"
}
fonts {
  name: "EB Garamond"
  style: "italic"
  weight: 400
  filename: "EBGaramond-Italic[wght].ttf"
  post_script_name: "EBGaramond-Italic"
  full_name: "EB Garamond Italic"
  copyright: "Copyright 2017 The EB Garamond Project Authors (https://github.com/octaviopardo/EBGaramond12)"
}
subsets: "cyrillic"
subsets: "cyrillic-ext"
subsets: "greek"
subsets: "greek-ext"
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "vietnamese"
axes {
  tag: "wght"
  min_value: 400.0
  max_value: 800.0
}
source {
  repository_url: "https://github.com/octaviopardo/EBGaramond12"
  commit: "106a4a6d377987459ae5e68673a4570f13b957fb"
  files {
    source_file: "fonts/variable/EBGaramond[wght].ttf"
    dest_file: "EBGaramond[wght].ttf"
  }
  files {
    source_file: "fonts/variable/EBGaramond-Italic[wght].ttf"
    dest_file: "EBGaramond-Italic[wght].ttf"
  }
  files {
    source_file: "OFL.txt"
    dest_file: "OFL.txt"
  }
  branch: "master"
  config_yaml: "sources/config.yaml"
}
minisite_url: "https://googlefonts.github.io/ebgaramond-specimen/"
