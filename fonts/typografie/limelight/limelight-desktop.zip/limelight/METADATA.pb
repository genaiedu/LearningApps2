name: "Limelight"
designer: "Nicole Fally, Sorkin Type"
license: "OFL"
category: "DISPLAY"
date_added: "2011-05-25"
fonts {
  name: "Limelight"
  style: "normal"
  weight: 400
  filename: "Limelight-Regular.ttf"
  post_script_name: "Limelight"
  full_name: "Limelight"
  copyright: "Copyright (c) 2010 by Sorkin Type Co (eben@eyebytes.com) with Reserved Font Name Limelight. This Font Software is licensed under the SIL Open Font License, Version 1.1. This license is available with a FAQ at: http://scripts.sil.org/OFL"
}
subsets: "menu"
subsets: "latin"
subsets: "latin-ext"
stroke: "SANS_SERIF"
classifications: "DISPLAY"
source {
  repository_url: "https://github.com/googlefonts/googlefontdirectory-hg"
  commit: "52f780bc9d197280a9f430574e179a5f233c56b6"
}
